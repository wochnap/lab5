angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.stronaGWna', {
    url: '/strona-glowna',
    views: {
      'tab5': {
        templateUrl: 'templates/stronaGWna.html',
        controller: 'stronaGWnaCtrl'
      }
    }
  })

  .state('tabsController.wydziaY', {
    url: '/wydzialy',
    views: {
      'tab5': {
        templateUrl: 'templates/wydziaY.html',
        controller: 'wydziaYCtrl'
      }
    }
  })

  .state('tabsController.wydziaElektryczny', {
    url: '/WE',
    views: {
      'tab5': {
        templateUrl: 'templates/wydziaElektryczny.html',
        controller: 'wydziaElektrycznyCtrl'
      }
    }
  })

  .state('tabsController.wydziaMechaniczny', {
    url: '/WM',
    views: {
      'tab5': {
        templateUrl: 'templates/wydziaMechaniczny.html',
        controller: 'wydziaMechanicznyCtrl'
      }
    }
  })

  .state('tabsController.wydziaNawigacyjny', {
    url: '/WN',
    views: {
      'tab5': {
        templateUrl: 'templates/wydziaNawigacyjny.html',
        controller: 'wydziaNawigacyjnyCtrl'
      }
    }
  })

  .state('tabsController.wydziaPrzedsiBiorczoCiITowaroznawstwa', {
    url: '/WPIT',
    views: {
      'tab5': {
        templateUrl: 'templates/wydziaPrzedsiBiorczoCiITowaroznawstwa.html',
        controller: 'wydziaPrzedsiBiorczoCiITowaroznawstwaCtrl'
      }
    }
  })

  .state('tabsController.studiujNaAM', {
    url: '/studiuj-na-AM',
    views: {
      'tab5': {
        templateUrl: 'templates/studiujNaAM.html',
        controller: 'studiujNaAMCtrl'
      }
    }
  })

  .state('tabsController.pytanie1', {
    url: '/pytanie1',
    views: {
      'tab5': {
        templateUrl: 'templates/pytanie1.html',
        controller: 'pytanie1Ctrl'
      }
    }
  })

  .state('tabsController.pytanie2', {
    url: '/pytanie2',
    views: {
      'tab5': {
        templateUrl: 'templates/pytanie2.html',
        controller: 'pytanie2Ctrl'
      }
    }
  })

  .state('tabsController.pytanie3', {
    url: '/pytanie3',
    views: {
      'tab5': {
        templateUrl: 'templates/pytanie3.html',
        controller: 'pytanie3Ctrl'
      }
    }
  })

  .state('tabsController.LE', {
    url: '/zle',
    views: {
      'tab5': {
        templateUrl: 'templates/LE.html',
        controller: 'LECtrl'
      }
    }
  })

  .state('tabsController.udaOCiSi', {
    url: '/udalo-ci-sie',
    views: {
      'tab5': {
        templateUrl: 'templates/udaOCiSi.html',
        controller: 'udaOCiSiCtrl'
      }
    }
  })

  .state('tabsController.galeria', {
    url: '/galeria',
    views: {
      'tab5': {
        templateUrl: 'templates/galeria.html',
        controller: 'galeriaCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/strona-glowna')

  

});